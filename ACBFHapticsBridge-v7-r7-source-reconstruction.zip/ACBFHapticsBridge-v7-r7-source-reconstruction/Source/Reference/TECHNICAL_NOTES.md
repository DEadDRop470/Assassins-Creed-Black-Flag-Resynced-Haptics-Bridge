# ACBFHapticsBridge v6-r6 technical notes

## Target and validation boundary

The hard-coded offsets are for Black Flag Resynced Steam TU 1.0.6 only:

- SHA-256 `8d52238155c9491f329c0b78af2d00ee67ab5e03946eea83e12b061b64b23140`
- physical file size `478845280` bytes
- PE32+ image base `0x140000000`
- image size `0x1DE27000`

`tools/validate_target_hooks.py` checks the full file hash, flush signature, all 21 state-vtable pointers, and the raw `XInputSetState` IAT entry. Runtime installation independently verifies the flush bytes and every original vtable pointer before writing that individual site.

## Quad Audio Haptics path

Black Flag's `AkQuadAudioHapticsSink` references `AkQuadAudioHapticsSink.cpp` and uses these relevant methods:

- RVA `0x04F781F0` consumes a planar two-channel `AkAudioBuffer`, applies packed start/end gains, and accumulates into `self+0x30`.
- RVA `0x04F78610` is the frame-final flush. Capacity is at `self+0x40`, valid frames at `self+0x42`, and the planar accumulator at `self+0x30`.

r6 detours the verified 16-byte flush prologue through a trampoline. Before native submission it detects pre-existing game energy, drains one-shot commands, mixes the selected 48 kHz stereo frames into the planar accumulator, applies the configured peak limit, and raises valid frames to the accumulator capacity.

The primary sink is no longer latched forever. Each primary call updates a monotonic timestamp; if a different sink begins calling after `SinkRebindAfterMs` of primary silence, it is adopted atomically. A flush resuming after `ReloadSilenceResetMs` also advances a recovery serial. The worker reacts by clearing stale actor/menu/airborne/deferred state, while the audio thread advances the playback generation before the replacement sink can drain an old command.

The audio hook is bounded and real-time safe for this use: it performs no allocation, file I/O, logging, controller API calls, sleeping, or lock acquisition.

## Gameplay-state vtable hooks

The state object owns an actor-related object at `state+0x08`; the actor context used to distinguish Edward from NPC state machines is reached through `owner+0xA8`. The configured `Jump`/`DodgeDive` action edges are used to bind that context. Once bound, unrelated actor transitions are rejected.

| State slot | Slot RVA | Expected function RVA | Use |
| --- | ---: | ---: | --- |
| InAir enter | `0x09151C18` | `0x015273A0` | Start airborne timing |
| InAir exit | `0x09151C20` | `0x017FC510` | Arm landing after sibling states settle |
| JumpOnSpot enter | `0x09152898` | `0x05E7F6C0` | Confirm short/in-place takeoff |
| FreeJump enter | `0x09152848` | `0x06B118E0` | Confirm free/running takeoff |
| TargetedJump enter | `0x0914E4E8` | `0x02750BF0` | Confirm targeted/climbing takeoff |
| Freefall enter | `0x0914E3F8` | `0x01FCD920` | Begin/continue an unpowered fall |
| FallFromLedge enter | `0x09151F38` | `0x06B01790` | Track building/ledge fall |
| FallFromLedge exit | `0x09151F40` | `0x06B01A30` | Settle the ledge-fall sibling flag |
| TransitionExit enter | `0x0914E218` | `0x06AFDB60` | Diagnostic traversal transition only |
| Climb A enter/exit | `0x09147A38/40` | `0x0152D180/0x0102CC10` | Suppress ground movement/dodge/landing |
| Climb B enter/exit | `0x0920DC90/98` | `0x06A98A70/0x06A99E00` | Second climb-state family |
| Swimming A enter/exit | `0x09159718/20` | `0x027D3CF0/0x018A3D00` | Water entry and exit settling |
| Swimming B enter/exit | `0x091A3928/30` | `0x08065C00/0x08066540` | Second full-swim family |
| ShallowSwim enter/exit | `0x0915AB98/A0` | `0x06C9ED00/0x06C9FAC0` | Surface/exit settling |
| HayStack enter/exit | `0x09145208/10` | `0x01B6C060/0x054F1850` | Dedicated leap-of-faith landing |

Wrappers preserve the original four-argument x64 call and invoke the original virtual function. They publish only small atomic event snapshots. The worker consumes those snapshots outside the game callback.

## Jump and landing state machine

The design is deliberately hybrid. The configured `Jump` edge on land emits a provisional takeoff immediately and arms `InputLandingFallbackMs`. A verified player Jump/InAir cycle owns the precise landing whenever available; the fallback only survives if the exit callback is missed. Direction is still required for a climbing jump, while a water `Jump` edge routes to the softer water effect and never arms a hard ground landing.

The r3 test log established why the fallback is needed: raw/accepted totals were 115/16, Jump was 21/3, Swimming was 3/0, and one accepted AIR entry remained latched for 83,297 ms. Input-adjacent Jump and Swimming-entry callbacks can replace a non-stale but incorrect actor binding. Only a stale AIR bit expires after `InputLandingTimeoutMs`; persistent swim and climb flags do not age out.

InAir and FallFromLedge are sibling airborne flags. A landing remains pending until both have cleared. The 32 ms settle delay prevents the first exit from being mistaken for ground during a same-transition handoff. Confirmed jumps bypass `MinimumAirborneMs`; unconfirmed micro-transitions do not.

Landing gain is piecewise linear over actual elapsed state time:

- `<= LandingShortAirMs`: `LandingShortGain`
- short to long threshold: interpolate to `LandingGain`
- long to max threshold: interpolate to `LandingLongGain`
- beyond max: cap at `LandingLongGain`

Climb, water, and haystack entry cancel a pending hard landing. HayStack uses its own softer effect, scaled relative to the same measured-airtime curve.

## Movement rendering

Stick state activates movement, while verified air/climb/water/haystack flags gate it. Ground walk uses the stable 2.280–3.810 s capture region. Run uses 3.100–4.935 s, excluding the source's silent and irregular tail. Each boundary is crossfaded and phase restarts on a mode transition.

`movementScalePermille` supplies the common base gain to both output renderers. `WalkGain`, `RunBaseGain`, and `RunOpeningGain` therefore still affect both. r6 then applies `Effect.Walk.DualSenseHapticMultiplier=2.00` only inside the native 48 kHz movement mixer; conventional rumble and running bypass it. The supplied values make sustained running 25% stronger than r2 and the first five seconds another 20% stronger than that sustained level. In water, the configured `SprintLunge` input starts the same sustained texture after a separate 1.20-gain lunge impact.

This is a calibrated fixed gait loop, not an animation-bone or exact foot-contact hook. Verified traversal flags prevent obvious wrong-state playback, but exact per-foot phase still requires an animation marker source.

## Conventional rumble path

Each trigger is duplicated into a worker-owned rumble timeline. At every poll it computes mean absolute energy and peak from the same source frames and maps them to low/high motor strengths. This preserves duration and relative dynamics, but two motors cannot reproduce stereo 48 kHz DualSense detail.

Input and rumble use the public GameInput v0 ABI already present in Black Flag. Methods are resolved dynamically; no GameInput import library or redistributable is linked. XInput is resolved dynamically as fallback.

GameInput v0's rumble setter returns void, so a virtual Xbox device can silently ignore it. For non-DualSense devices the bridge mirrors the same motor state through XInput. This is why DSX Xbox 360 mode can work even when GameInput supplied the input reading.

r6 identifies the XInput running path when input is supplied directly by XInput or when GameInput reports Microsoft vendor `0x045E` (including the usual DSX/ViGEm Xbox 360 identity). Instead of measuring every consecutive 8 ms run slice, it emits a 75 ms motor contact every 300 ms. Each contact uses `run_sustained_sample.maxAbs` with the current run, motor-scale and INI gains, so contacts are repeatable capture-peak events rather than arbitrary waveform slices. The 225 ms zero-output gap stops the previous nearly continuous feel. The parry-derived sprint-kick motor voice is suppressed only while this pulse mode owns running; native haptics retain it.

## Playback onset and action latency

Each one-shot command now carries an optional starting frame shared by the Quad-haptic and rumble renderers. Preview keys always start at frame zero. Automatic mappings can skip measured quiet lead-ins without time-stretching or changing the remaining waveform:

| Automatic action | Start trim | Probe |
| --- | ---: | ---: |
| Ground dodge | 197 ms (25% of the 787.8 ms clip) | 20 ms |
| Directional dodge and state impacts | 236 ms (30%) | 20 ms |
| Parry and heavy impacts | 48 ms | 60 ms |
| D-pad Left hood/sheathe | 0 ms | 0 ms |
| Menu short tick | 0 ms | 20 ms |
| Menu L1/R1 fallback | 0 ms | 20 ms |

The configured `Attack` hold (R1 by default) commits at 320 ms and its second
impact is 640 ms start-to-start, both 20% shorter than r3.

## Configurable action-binding layer

GameInput readings are normalized to the same XInput-shaped internal state as
the XInput fallback. `[InputBindings]` is parsed once at startup into a binding
type plus either a digital bit or analog-trigger selector. Edge/down/release
helpers then drive the six semantic actions: `Jump`, `DodgeDive`, `Parry`,
`Attack`, `SprintLunge`, and `SheatheHood`.

The action abstraction is applied before gameplay dispatch. In particular,
`Jump` updates the recent-input timestamp, held state, stick magnitude, player
candidate binding, immediate takeoff, and later Jump-state gate together.
`DodgeDive` likewise moves its Swimming-entry correlation. `Attack` preserves
press, hold-threshold, release, and delayed second-impact behavior on a digital
button or L2/R2 analog threshold. `SprintLunge` supports either toggle or hold
semantics on every accepted input.

Invalid values fall back individually to the tested defaults and increment
`invalidFallbacks` in the F10 `INPUTCFG` line. `None` creates no direct edge;
it does not disable independent state-only effects. Menu openers and navigation
remain outside this action layer so the menu inference cannot be accidentally
reassigned to a gameplay action.

## Per-effect configuration layer

Every implemented automatic action has an `Effect.*` INI section. `Enabled` gates only that output request; state tracking and unrelated effects continue. `IntensityMultiplier` is applied to the calibrated action gain before the common one-shot/movement, master, and rumble conversion gains. Therefore one setting changes full haptics and ordinary rumble together.

For one-shots, `TriggerOffsetMs` is added to the action's calibrated native-probe delay and clamped at zero, while `StartTrimOffsetMs` is added to its calibrated waveform offset and converted to 48 kHz frames. Signed offsets are clamped to +/-5000 ms and the final value to 0-60000 ms. They never alter game time, animation time, or the sampling rate.

Short, normal and long landing controls are selected after airtime classification, so each part of the piecewise strength curve can be disabled or scaled independently. The two R1-heavy impacts likewise use separate controls. Walk and run remain continuous render paths: their effect switches gate the selected sample and their timing is controlled by loop bounds, fade duration, and run-opening duration instead of a one-shot trigger offset.

The calibrated legacy keys remain the compatibility layer. The shipped general per-effect multipliers and offsets are neutral except for the explicitly stronger r5 menu tick. r6 adds the output-specific 2.00x DualSense walk multiplier and XInput run-pulse settings without altering ordinary Xbox/DS4 walking or native DualSense running. F10 appends `EFFECTCFG` lines in `enabled/intensity/trigger-offset/start-trim-offset` order and reports pulse configuration/activity for reproducible troubleshooting.

## Native-output arbitration

The bridge detects native output before adding a fallback:

- Quad Audio Haptics: peak/mean energy is measured before ASI mixing.
- XInput: the exact game IAT slot at RVA `0x1D0119E0` is wrapped; bridge writes use the resolved export directly and do not pass through that slot.
- GameInput: vtable method 10 (`SetRumbleState`) is wrapped for observed devices. The bridge's own writer thread is excluded.

Every qualifying native write increments a serial. A deferred effect stores the serial present when its originating input occurred. If that serial changes during the probe—even if native rumble has ended before the due time—the fallback is discarded. This is important for short sword clashes and parries.

When native game rumble is active, the ASI does not issue a competing zero because that would cancel the game effect. When native Quad haptics begins while the ASI owns a conventional motor state, it clears that ASI-owned state once and then yields.

## Menu-domain feedback and isolation

A stable live map/inventory object pointer has not been proven for this executable. r5 requests `GameInputKindGamepad | GameInputKindControllerButton` in one cached reading. The normalized view supplies ordinary controls; methods 10/11 expose the controller-button count and state. On Sony vendor `0x054C`, raw button index 13 defaults to the DualSense touchpad click and immediately enters/asserts the menu domain. Start/Back remains available, and native feedback after both L1 and R1 within 2.5 seconds is the fallback arm for unusual virtual-device mappings.

Once active, D-pad/left-stick directions and face selections request `weapon_transition_short` at 0.35 gain. L1/R1 request `parry` at 0.315 gain, 70% of the 0.45 gameplay-parry amplitude. D-pad Left cannot fall through to gameplay sheathe. The session closes on its normalized opener, timeout, or Circle/B followed by sustained movement; a 48 ms resume guard consumes held menu controls.

Every queued haptic/rumble command carries the cancellation generation captured at enqueue time. Entering or leaving menu mode clears deferred work and advances that generation, so commands from one domain cannot execute in the other even if the audio and controller threads cross at the boundary. Accepted gameplay-state counters are advanced without dispatch while menu/transition guard is active.

All menu requests use native arbitration. Existing Animus/right-tile feedback therefore wins, while the ASI fills silent map/inventory gaps. `[Menus] Enabled=0` disables only synthesized menu pulses; detection and gameplay-effect isolation remain active.

## HFX pack

`ShadowsHapticsPack-v5.hfx` contains:

- a 40-byte `SHFXPK1` header;
- 14 fixed 80-byte entries;
- exact interleaved stereo float32 samples at 48,000 Hz.

The 14 effects are `dodge`, `walk_footsteps_sample`, `run_sustained_sample`, `light_attack_single`, `light_attack_combo3`, `light_attack_combo4`, `weapon_sheathe_unsheathe_full`, `weapon_transition_short`, `parry`, `enemy_hit`, `player_hit`, `environment_general_sample`, `charged_r1`, and `heavy_r2`.

## Build characteristics

The GNU build uses freestanding C++17, disables exceptions/RTTI/unwind tables and stack-protector runtime dependencies, links directly as PE32+, strips exported symbols, omits build IDs/timestamps, and retains relocations. A normal import table is not required because Windows exports are resolved from the PEB at runtime. INI parsing occurs once on the worker thread during startup; per-frame code reads already-clamped fields and adds no file I/O.
