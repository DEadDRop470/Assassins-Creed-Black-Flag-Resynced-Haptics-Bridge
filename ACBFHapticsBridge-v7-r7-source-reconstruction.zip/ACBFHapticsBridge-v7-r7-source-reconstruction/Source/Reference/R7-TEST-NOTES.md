# ACBFHapticsBridge r7 test notes

Build: `v7-r7-kick-walk4x`

## Changes from r6

- Added gameplay kick fallback: **hold R2, then press Square**.
- Kick reuses the HFX `parry` waveform.
- Square alone does not trigger the kick. Pressing R2 after Square is already held does not trigger it; the Square press edge must occur while R2 is held.
- R2 uses the configured `[Input] TriggerThreshold` (default 160).
- Kick gain reads `LBEffectGain` (default 0.45), matching the normal parry fallback strength.
- Existing menu consumption remains ahead of raw gameplay mappings, so the kick should not fire from menu navigation.
- DualSense native walking multiplier increased from r6 `2.00` to `4.00`. Conventional walking rumble is unchanged.

## Focused test

1. Start gameplay on foot with DualSense/DSX as used for r6.
2. Verify normal walking is clearly stronger in native haptics than r6.
3. Press Square by itself: no added parry/kick haptic should play.
4. Hold R2, then tap Square once: one parry-derived kick impact should play.
5. Keep Square held: it should not continuously retrigger.
6. Hold Square first, then press R2: no kick should be added.
7. Open World/Map/Inventory and navigate: R2+Square should not create stray gameplay kick feedback.
8. Press F10 and save the resulting `ACBFHapticsBridge-v7.log` for review.
