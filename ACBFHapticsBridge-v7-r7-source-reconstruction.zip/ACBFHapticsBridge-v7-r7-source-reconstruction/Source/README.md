# ACBFHapticsBridge v7-r7 source reconstruction

Target build: `ACBFHapticsBridge-v7-r7-kick-walk4x-test`

Verified ASI SHA-256:
`fb77b55728185e453fcc2046716f1d299bb78e92aededae906c9c56db58383b9`

## What is here

- `RECONSTRUCTED-R7.cpp` — source-level reconstruction of the R7-specific behavior.
- `r7_kick_stub.S` — exact 28-byte injected R2+Square gate represented as assembly source.
- `audit_r7.py` — verifies the known R7 binary, PE layout, branch, stub, threshold and gain pointer.
- `Base/ACBFHapticsBridge-v7-r7-original.asi` — exact verified R7 ASI reference binary.
- `Reference/ACBFHapticsBridge-v7.ini` — matching R7 configuration.
- `Reference/R7-BINARY-PATCH.md` — original binary-patch notes from the R7 package.
- `Reference/R7-TEST-NOTES.md` — original R7 test notes.
- `Reference/TECHNICAL_NOTES.md` — inherited R6 runtime architecture notes.

## Important provenance note

The original R7 package did not contain the full C++/Visual Studio source for the ASI.
Its own `R7-BINARY-PATCH.md` states that the uploaded R6 package contained the compiled
ASI but no C++/Visual Studio source, so R7 was produced as a narrow binary patch on top
of that R6 runtime.

For that reason this package does not falsely claim to be the lost original source.
It preserves the exact R7-added machine-code stub and provides a source-level
reconstruction of the R7 behavior around the verified original R7 binary.
